import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  //Variaveis e condições
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefoneController = TextEditingController();

  void abrirFormulario(contato) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Cadastro"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nomeController,
                decoration: InputDecoration(label: Text("Nome")),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _telefoneController,
                decoration: InputDecoration(label: Text("Telefone")),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(label: Text("Email")),
              ),
              SizedBox(height: 20),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Fechar"),
            ),
            TextButton(onPressed: () {}, child: Text("Salvar")),
          ],
        );
      },
    );
  }

  //==================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Lista de Contatos",
          style: TextStyle(color: (Colors.white)),
        ),
        backgroundColor: Colors.black54,
      ),
      body: ListView.builder(
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: ListTile(
              title: Text('Titulo'),
              subtitle: Text('Subtitulo'),
              //trailing = Icone de "notificação"
              trailing: IconButton(onPressed: () {}, icon: Icon(Icons.edit)),
              //leading = foto dos seres humanos
              leading: CircleAvatar(child: Icon(Icons.person)),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          abrirFormulario(null);
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
